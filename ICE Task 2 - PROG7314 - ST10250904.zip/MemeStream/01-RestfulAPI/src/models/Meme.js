import mongoose from "mongoose";

const MemeSchema = new mongoose.Schema(
  {
    userId:  { type: String, required: true, index: true },
    title:   { type: String, required: true, trim: true },
    imageUrl:{ type: String, required: true, trim: true },
    tags:    { type: [String], default: [] },
    likes:   { type: Number, default: 0 }
  },
  { timestamps: true } // createdAt, updatedAt
);

export default mongoose.model("Meme", MemeSchema);
