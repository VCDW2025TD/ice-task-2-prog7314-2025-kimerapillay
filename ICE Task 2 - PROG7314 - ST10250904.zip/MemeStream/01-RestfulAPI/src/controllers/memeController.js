import Meme from "../models/Meme.js";

// POST /memes -> create
export const createMeme = async (req, res) => {
  try {
    const { userId, title, imageUrl, tags } = req.body;
    if (!userId || !title || !imageUrl) {
      return res.status(400).json({ message: "userId, title and imageUrl are required." });
    }
    const meme = await Meme.create({ userId, title, imageUrl, tags });
    return res.status(201).json(meme);
  } catch (err) {
    console.error("POST /memes error:", err);
    res.status(500).json({ message: "Server error creating meme." });
  }
};

// GET /memes[?userId=...][&page=1&limit=50] -> list
export const getMemes = async (req, res) => {
  try {
    const { userId, page = 1, limit = 50 } = req.query;
    const filter = userId ? { userId } : {};
    const skip = (Number(page) - 1) * Number(limit);

    const [items, total] = await Promise.all([
      Meme.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Meme.countDocuments(filter)
    ]);

    res.json({
      items,
      page: Number(page),
      limit: Number(limit),
      total,
      totalPages: Math.ceil(total / Number(limit))
    });
  } catch (err) {
    console.error("GET /memes error:", err);
    res.status(500).json({ message: "Server error fetching memes." });
  }
};
